Here live the files that are required to build with the visual studio 2010 IDE

Depends on:
latest DX sdk
active perl
(maybe) visual studio 2010 sp1 
