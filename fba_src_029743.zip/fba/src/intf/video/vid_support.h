void VidSFreeVidImage();
INT32 VidSAllocVidImage();
