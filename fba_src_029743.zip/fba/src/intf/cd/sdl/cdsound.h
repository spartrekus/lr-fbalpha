#ifndef _WavClass_H_
#define _WavClass_H_

void	wav_exit();
int		wav_open(TCHAR* szFile);
void	wav_stop();
void	wav_play();

#endif
