#include "burner.h"
#include "cd_interface.h"

void wav_exit()
{
}

int wav_open(TCHAR* szFile)
{
}

void wav_stop() 
{
}

void wav_play()
{
}

void wav_pause(bool bResume)
{
}
