// dsp.cpp
INT32 DspInit();
INT32 DspExit();
INT32 DspDo(INT16* Wave, INT32 nCount);
