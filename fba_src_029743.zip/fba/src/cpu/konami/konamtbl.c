KONAMI_INLINE void abx(void);
KONAMI_INLINE void adca_di(void);
KONAMI_INLINE void adca_ex(void);
KONAMI_INLINE void adca_im(void);
KONAMI_INLINE void adca_ix(void);
KONAMI_INLINE void adcb_di(void);
KONAMI_INLINE void adcb_ex(void);
KONAMI_INLINE void adcb_im(void);
KONAMI_INLINE void adcb_ix(void);
KONAMI_INLINE void adda_di(void);
KONAMI_INLINE void adda_ex(void);
KONAMI_INLINE void adda_im(void);
KONAMI_INLINE void adda_ix(void);
KONAMI_INLINE void addb_di(void);
KONAMI_INLINE void addb_ex(void);
KONAMI_INLINE void addb_im(void);
KONAMI_INLINE void addb_ix(void);
KONAMI_INLINE void addd_di(void);
KONAMI_INLINE void addd_ex(void);
KONAMI_INLINE void addd_im(void);
KONAMI_INLINE void addd_ix(void);
KONAMI_INLINE void anda_di(void);
KONAMI_INLINE void anda_ex(void);
KONAMI_INLINE void anda_im(void);
KONAMI_INLINE void anda_ix(void);
KONAMI_INLINE void andb_di(void);
KONAMI_INLINE void andb_ex(void);
KONAMI_INLINE void andb_im(void);
KONAMI_INLINE void andb_ix(void);
KONAMI_INLINE void andcc(void);
KONAMI_INLINE void asl_di(void);
KONAMI_INLINE void asl_ex(void);
KONAMI_INLINE void asl_ix(void);
KONAMI_INLINE void asla(void);
KONAMI_INLINE void aslb(void);
KONAMI_INLINE void asr_di(void);
KONAMI_INLINE void asr_ex(void);
KONAMI_INLINE void asr_ix(void);
KONAMI_INLINE void asra(void);
KONAMI_INLINE void asrb(void);
KONAMI_INLINE void bcc(void);
KONAMI_INLINE void bcs(void);
KONAMI_INLINE void beq(void);
KONAMI_INLINE void bge(void);
KONAMI_INLINE void bgt(void);
KONAMI_INLINE void bhi(void);
KONAMI_INLINE void bita_di(void);
KONAMI_INLINE void bita_ex(void);
KONAMI_INLINE void bita_im(void);
KONAMI_INLINE void bita_ix(void);
KONAMI_INLINE void bitb_di(void);
KONAMI_INLINE void bitb_ex(void);
KONAMI_INLINE void bitb_im(void);
KONAMI_INLINE void bitb_ix(void);
KONAMI_INLINE void ble(void);
KONAMI_INLINE void bls(void);
KONAMI_INLINE void blt(void);
KONAMI_INLINE void bmi(void);
KONAMI_INLINE void bne(void);
KONAMI_INLINE void bpl(void);
KONAMI_INLINE void bra(void);
KONAMI_INLINE void brn(void);
KONAMI_INLINE void bsr(void);
KONAMI_INLINE void bvc(void);
KONAMI_INLINE void bvs(void);
KONAMI_INLINE void clr_di(void);
KONAMI_INLINE void clr_ex(void);
KONAMI_INLINE void clr_ix(void);
KONAMI_INLINE void clra(void);
KONAMI_INLINE void clrb(void);
KONAMI_INLINE void cmpa_di(void);
KONAMI_INLINE void cmpa_ex(void);
KONAMI_INLINE void cmpa_im(void);
KONAMI_INLINE void cmpa_ix(void);
KONAMI_INLINE void cmpb_di(void);
KONAMI_INLINE void cmpb_ex(void);
KONAMI_INLINE void cmpb_im(void);
KONAMI_INLINE void cmpb_ix(void);
KONAMI_INLINE void cmpd_di(void);
KONAMI_INLINE void cmpd_ex(void);
KONAMI_INLINE void cmpd_im(void);
KONAMI_INLINE void cmpd_ix(void);
KONAMI_INLINE void cmps_di(void);
KONAMI_INLINE void cmps_ex(void);
KONAMI_INLINE void cmps_im(void);
KONAMI_INLINE void cmps_ix(void);
KONAMI_INLINE void cmpu_di(void);
KONAMI_INLINE void cmpu_ex(void);
KONAMI_INLINE void cmpu_im(void);
KONAMI_INLINE void cmpu_ix(void);
KONAMI_INLINE void cmpx_di(void);
KONAMI_INLINE void cmpx_ex(void);
KONAMI_INLINE void cmpx_im(void);
KONAMI_INLINE void cmpx_ix(void);
KONAMI_INLINE void cmpy_di(void);
KONAMI_INLINE void cmpy_ex(void);
KONAMI_INLINE void cmpy_im(void);
KONAMI_INLINE void cmpy_ix(void);
KONAMI_INLINE void com_di(void);
KONAMI_INLINE void com_ex(void);
KONAMI_INLINE void com_ix(void);
KONAMI_INLINE void coma(void);
KONAMI_INLINE void comb(void);
KONAMI_INLINE void cwai(void);
KONAMI_INLINE void daa(void);
KONAMI_INLINE void dec_di(void);
KONAMI_INLINE void dec_ex(void);
KONAMI_INLINE void dec_ix(void);
KONAMI_INLINE void deca(void);
KONAMI_INLINE void decb(void);
KONAMI_INLINE void eora_di(void);
KONAMI_INLINE void eora_ex(void);
KONAMI_INLINE void eora_im(void);
KONAMI_INLINE void eora_ix(void);
KONAMI_INLINE void eorb_di(void);
KONAMI_INLINE void eorb_ex(void);
KONAMI_INLINE void eorb_im(void);
KONAMI_INLINE void eorb_ix(void);
KONAMI_INLINE void exg(void);
KONAMI_INLINE void illegal(void);
KONAMI_INLINE void inc_di(void);
KONAMI_INLINE void inc_ex(void);
KONAMI_INLINE void inc_ix(void);
KONAMI_INLINE void inca(void);
KONAMI_INLINE void incb(void);
KONAMI_INLINE void jmp_di(void);
KONAMI_INLINE void jmp_ex(void);
KONAMI_INLINE void jmp_ix(void);
KONAMI_INLINE void jsr_di(void);
KONAMI_INLINE void jsr_ex(void);
KONAMI_INLINE void jsr_ix(void);
KONAMI_INLINE void lbcc(void);
KONAMI_INLINE void lbcs(void);
KONAMI_INLINE void lbeq(void);
KONAMI_INLINE void lbge(void);
KONAMI_INLINE void lbgt(void);
KONAMI_INLINE void lbhi(void);
KONAMI_INLINE void lble(void);
KONAMI_INLINE void lbls(void);
KONAMI_INLINE void lblt(void);
KONAMI_INLINE void lbmi(void);
KONAMI_INLINE void lbne(void);
KONAMI_INLINE void lbpl(void);
KONAMI_INLINE void lbra(void);
KONAMI_INLINE void lbrn(void);
KONAMI_INLINE void lbsr(void);
KONAMI_INLINE void lbvc(void);
KONAMI_INLINE void lbvs(void);
KONAMI_INLINE void lda_di(void);
KONAMI_INLINE void lda_ex(void);
KONAMI_INLINE void lda_im(void);
KONAMI_INLINE void lda_ix(void);
KONAMI_INLINE void ldb_di(void);
KONAMI_INLINE void ldb_ex(void);
KONAMI_INLINE void ldb_im(void);
KONAMI_INLINE void ldb_ix(void);
KONAMI_INLINE void ldd_di(void);
KONAMI_INLINE void ldd_ex(void);
KONAMI_INLINE void ldd_im(void);
KONAMI_INLINE void ldd_ix(void);
KONAMI_INLINE void lds_di(void);
KONAMI_INLINE void lds_ex(void);
KONAMI_INLINE void lds_im(void);
KONAMI_INLINE void lds_ix(void);
KONAMI_INLINE void ldu_di(void);
KONAMI_INLINE void ldu_ex(void);
KONAMI_INLINE void ldu_im(void);
KONAMI_INLINE void ldu_ix(void);
KONAMI_INLINE void ldx_di(void);
KONAMI_INLINE void ldx_ex(void);
KONAMI_INLINE void ldx_im(void);
KONAMI_INLINE void ldx_ix(void);
KONAMI_INLINE void ldy_di(void);
KONAMI_INLINE void ldy_ex(void);
KONAMI_INLINE void ldy_im(void);
KONAMI_INLINE void ldy_ix(void);
KONAMI_INLINE void leas(void);
KONAMI_INLINE void leau(void);
KONAMI_INLINE void leax(void);
KONAMI_INLINE void leay(void);
KONAMI_INLINE void lsr_di(void);
KONAMI_INLINE void lsr_ex(void);
KONAMI_INLINE void lsr_ix(void);
KONAMI_INLINE void lsra(void);
KONAMI_INLINE void lsrb(void);
KONAMI_INLINE void mul(void);
KONAMI_INLINE void neg_di(void);
KONAMI_INLINE void neg_ex(void);
KONAMI_INLINE void neg_ix(void);
KONAMI_INLINE void nega(void);
KONAMI_INLINE void negb(void);
KONAMI_INLINE void nop(void);
KONAMI_INLINE void ora_di(void);
KONAMI_INLINE void ora_ex(void);
KONAMI_INLINE void ora_im(void);
KONAMI_INLINE void ora_ix(void);
KONAMI_INLINE void orb_di(void);
KONAMI_INLINE void orb_ex(void);
KONAMI_INLINE void orb_im(void);
KONAMI_INLINE void orb_ix(void);
KONAMI_INLINE void orcc(void);
KONAMI_INLINE void pshs(void);
KONAMI_INLINE void pshu(void);
KONAMI_INLINE void puls(void);
KONAMI_INLINE void pulu(void);
KONAMI_INLINE void rol_di(void);
KONAMI_INLINE void rol_ex(void);
KONAMI_INLINE void rol_ix(void);
KONAMI_INLINE void rola(void);
KONAMI_INLINE void rolb(void);
KONAMI_INLINE void ror_di(void);
KONAMI_INLINE void ror_ex(void);
KONAMI_INLINE void ror_ix(void);
KONAMI_INLINE void rora(void);
KONAMI_INLINE void rorb(void);
KONAMI_INLINE void rti(void);
KONAMI_INLINE void rts(void);
KONAMI_INLINE void sbca_di(void);
KONAMI_INLINE void sbca_ex(void);
KONAMI_INLINE void sbca_im(void);
KONAMI_INLINE void sbca_ix(void);
KONAMI_INLINE void sbcb_di(void);
KONAMI_INLINE void sbcb_ex(void);
KONAMI_INLINE void sbcb_im(void);
KONAMI_INLINE void sbcb_ix(void);
KONAMI_INLINE void sex(void);
KONAMI_INLINE void sta_di(void);
KONAMI_INLINE void sta_ex(void);
KONAMI_INLINE void sta_im(void);
KONAMI_INLINE void sta_ix(void);
KONAMI_INLINE void stb_di(void);
KONAMI_INLINE void stb_ex(void);
KONAMI_INLINE void stb_im(void);
KONAMI_INLINE void stb_ix(void);
KONAMI_INLINE void std_di(void);
KONAMI_INLINE void std_ex(void);
KONAMI_INLINE void std_im(void);
KONAMI_INLINE void std_ix(void);
KONAMI_INLINE void sts_di(void);
KONAMI_INLINE void sts_ex(void);
KONAMI_INLINE void sts_im(void);
KONAMI_INLINE void sts_ix(void);
KONAMI_INLINE void stu_di(void);
KONAMI_INLINE void stu_ex(void);
KONAMI_INLINE void stu_im(void);
KONAMI_INLINE void stu_ix(void);
KONAMI_INLINE void stx_di(void);
KONAMI_INLINE void stx_ex(void);
KONAMI_INLINE void stx_im(void);
KONAMI_INLINE void stx_ix(void);
KONAMI_INLINE void sty_di(void);
KONAMI_INLINE void sty_ex(void);
KONAMI_INLINE void sty_im(void);
KONAMI_INLINE void sty_ix(void);
KONAMI_INLINE void suba_di(void);
KONAMI_INLINE void suba_ex(void);
KONAMI_INLINE void suba_im(void);
KONAMI_INLINE void suba_ix(void);
KONAMI_INLINE void subb_di(void);
KONAMI_INLINE void subb_ex(void);
KONAMI_INLINE void subb_im(void);
KONAMI_INLINE void subb_ix(void);
KONAMI_INLINE void subd_di(void);
KONAMI_INLINE void subd_ex(void);
KONAMI_INLINE void subd_im(void);
KONAMI_INLINE void subd_ix(void);
KONAMI_INLINE void swi(void);
KONAMI_INLINE void swi2(void);
KONAMI_INLINE void swi3(void);
KONAMI_INLINE void sync(void);
KONAMI_INLINE void tfr(void);
KONAMI_INLINE void tst_di(void);
KONAMI_INLINE void tst_ex(void);
KONAMI_INLINE void tst_ix(void);
KONAMI_INLINE void tsta(void);
KONAMI_INLINE void tstb(void);

KONAMI_INLINE void clrd(void); /* 6309 */
KONAMI_INLINE void clrw_ix(void); /* 6309 ? */
KONAMI_INLINE void clrw_di(void); /* 6309 ? */
KONAMI_INLINE void clrw_ex(void); /* 6309 ? */
KONAMI_INLINE void negd(void);
KONAMI_INLINE void negw_ix(void); /* 6309 ? */
KONAMI_INLINE void negw_di(void); /* 6309 ? */
KONAMI_INLINE void negw_ex(void); /* 6309 ? */
KONAMI_INLINE void lsrd( void ); /* 6309 */
KONAMI_INLINE void lsrd_di( void ); /* 6309 */
KONAMI_INLINE void lsrd_ix( void ); /* 6309 */
KONAMI_INLINE void lsrd_ex( void ); /* 6309 */
KONAMI_INLINE void rord( void ); /* 6309 ? */
KONAMI_INLINE void rord_di( void ); /* 6309 */
KONAMI_INLINE void rord_ix( void ); /* 6309 */
KONAMI_INLINE void rord_ex( void ); /* 6309 */
KONAMI_INLINE void asrd( void ); /* 6309 ? */
KONAMI_INLINE void asrd_di( void ); /* 6309 */
KONAMI_INLINE void asrd_ix( void ); /* 6309 */
KONAMI_INLINE void asrd_ex( void ); /* 6309 */
KONAMI_INLINE void asld( void ); /* 6309 */
KONAMI_INLINE void asld_di( void ); /* 6309 */
KONAMI_INLINE void asld_ix( void ); /* 6309 */
KONAMI_INLINE void asld_ex( void ); /* 6309 */
KONAMI_INLINE void rold( void ); /* 6309 ? */
KONAMI_INLINE void rold_di( void ); /* 6309 */
KONAMI_INLINE void rold_ix( void ); /* 6309 */
KONAMI_INLINE void rold_ex( void ); /* 6309 */
KONAMI_INLINE void tstd(void);
KONAMI_INLINE void tstw_di( void );
KONAMI_INLINE void tstw_ix( void );
KONAMI_INLINE void tstw_ex( void );

/* Custom opcodes */
KONAMI_INLINE void setline_im( void );
KONAMI_INLINE void setline_ix( void );
KONAMI_INLINE void setline_di( void );
KONAMI_INLINE void setline_ex( void );
KONAMI_INLINE void bmove( void );
KONAMI_INLINE void move( void );
KONAMI_INLINE void decbjnz( void );
KONAMI_INLINE void decxjnz( void );
KONAMI_INLINE void bset( void );
KONAMI_INLINE void bset2( void );
KONAMI_INLINE void lmul(void);
KONAMI_INLINE void divx( void );
KONAMI_INLINE void incd( void );
KONAMI_INLINE void incw_di( void );
KONAMI_INLINE void incw_ix( void );
KONAMI_INLINE void incw_ex( void );
KONAMI_INLINE void decd( void );
KONAMI_INLINE void decw_di( void );
KONAMI_INLINE void decw_ix( void );
KONAMI_INLINE void decw_ex( void );
KONAMI_INLINE void lsrw_di( void );
KONAMI_INLINE void lsrw_ix( void );
KONAMI_INLINE void lsrw_ex( void );
KONAMI_INLINE void rorw_di( void );
KONAMI_INLINE void rorw_ix( void );
KONAMI_INLINE void rorw_ex( void );
KONAMI_INLINE void asrw_di( void );
KONAMI_INLINE void asrw_ix( void );
KONAMI_INLINE void asrw_ex( void );
KONAMI_INLINE void aslw_di( void );
KONAMI_INLINE void aslw_ix( void );
KONAMI_INLINE void aslw_ex( void );
KONAMI_INLINE void rolw_di( void );
KONAMI_INLINE void rolw_ix( void );
KONAMI_INLINE void rolw_ex( void );
KONAMI_INLINE void absa( void );
KONAMI_INLINE void absb( void );
KONAMI_INLINE void absd( void );

KONAMI_INLINE void opcode2( void );

static void (*const konami_main[0x100])(void) = {
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 00 */
	opcode2,opcode2,opcode2,opcode2,pshs   ,pshu   ,puls   ,pulu   ,
	lda_im ,ldb_im ,opcode2,opcode2,adda_im,addb_im,opcode2,opcode2,	/* 10 */
	adca_im,adcb_im,opcode2,opcode2,suba_im,subb_im,opcode2,opcode2,
	sbca_im,sbcb_im,opcode2,opcode2,anda_im,andb_im,opcode2,opcode2,	/* 20 */
	bita_im,bitb_im,opcode2,opcode2,eora_im,eorb_im,opcode2,opcode2,
	ora_im ,orb_im ,opcode2,opcode2,cmpa_im,cmpb_im,opcode2,opcode2,	/* 30 */
	setline_im,opcode2,opcode2,opcode2,andcc,orcc  ,exg    ,tfr    ,
	ldd_im ,opcode2,ldx_im ,opcode2,ldy_im ,opcode2,ldu_im ,opcode2,	/* 40 */
	lds_im ,opcode2,cmpd_im,opcode2,cmpx_im,opcode2,cmpy_im,opcode2,
	cmpu_im,opcode2,cmps_im,opcode2,addd_im,opcode2,subd_im,opcode2,	/* 50 */
	opcode2,opcode2,opcode2,opcode2,opcode2,illegal,illegal,illegal,
	bra    ,bhi    ,bcc    ,bne    ,bvc    ,bpl    ,bge    ,bgt    ,	/* 60 */
	lbra   ,lbhi   ,lbcc   ,lbne   ,lbvc   ,lbpl   ,lbge   ,lbgt   ,
	brn    ,bls    ,bcs    ,beq    ,bvs    ,bmi    ,blt    ,ble    ,	/* 70 */
	lbrn   ,lbls   ,lbcs   ,lbeq   ,lbvs   ,lbmi   ,lblt   ,lble   ,
	clra   ,clrb   ,opcode2,coma   ,comb   ,opcode2,nega   ,negb   ,	/* 80 */
	opcode2,inca   ,incb   ,opcode2,deca   ,decb   ,opcode2,rts    ,
	tsta   ,tstb   ,opcode2,lsra   ,lsrb   ,opcode2,rora   ,rorb   ,	/* 90 */
	opcode2,asra   ,asrb   ,opcode2,asla   ,aslb   ,opcode2,rti    ,
	rola   ,rolb   ,opcode2,opcode2,opcode2,opcode2,opcode2,opcode2,	/* a0 */
	opcode2,opcode2,bsr    ,lbsr   ,decbjnz,decxjnz,nop    ,illegal,
	abx    ,daa	   ,sex    ,mul    ,lmul   ,divx   ,bmove  ,move   ,	/* b0 */
	lsrd   ,opcode2,rord   ,opcode2,asrd   ,opcode2,asld   ,opcode2,
	rold   ,opcode2,clrd   ,opcode2,negd   ,opcode2,incd   ,opcode2,	/* c0 */
	decd   ,opcode2,tstd   ,opcode2,absa   ,absb   ,absd   ,bset   ,
	bset2  ,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* d0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* e0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* f0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal
};

static void (*const konami_indexed[0x100])(void) = {
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 00 */
	leax   ,leay   ,leau   ,leas   ,illegal,illegal,illegal,illegal,
	illegal,illegal,lda_ix ,ldb_ix ,illegal,illegal,adda_ix,addb_ix,	/* 10 */
	illegal,illegal,adca_ix,adcb_ix,illegal,illegal,suba_ix,subb_ix,
	illegal,illegal,sbca_ix,sbcb_ix,illegal,illegal,anda_ix,andb_ix,	/* 20 */
	illegal,illegal,bita_ix,bitb_ix,illegal,illegal,eora_ix,eorb_ix,
	illegal,illegal,ora_ix ,orb_ix ,illegal,illegal,cmpa_ix,cmpb_ix,	/* 30 */
	illegal,setline_ix,sta_ix,stb_ix,illegal,illegal,illegal,illegal,
	illegal,ldd_ix ,illegal,ldx_ix ,illegal,ldy_ix ,illegal,ldu_ix ,	/* 40 */
	illegal,lds_ix ,illegal,cmpd_ix,illegal,cmpx_ix,illegal,cmpy_ix,
	illegal,cmpu_ix,illegal,cmps_ix,illegal,addd_ix,illegal,subd_ix,	/* 50 */
	std_ix ,stx_ix ,sty_ix ,stu_ix ,sts_ix ,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 60 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 70 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,clr_ix ,illegal,illegal,com_ix ,illegal,illegal,	/* 80 */
	neg_ix ,illegal,illegal,inc_ix ,illegal,illegal,dec_ix ,illegal,
	illegal,illegal,tst_ix ,illegal,illegal,lsr_ix ,illegal,illegal,	/* 90 */
	ror_ix ,illegal,illegal,asr_ix ,illegal,illegal,asl_ix ,illegal,
	illegal,illegal,rol_ix ,lsrw_ix,rorw_ix,asrw_ix,aslw_ix,rolw_ix,	/* a0 */
	jmp_ix ,jsr_ix ,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* b0 */
	illegal,lsrd_ix,illegal,rord_ix,illegal,asrd_ix,illegal,asld_ix,
	illegal,rold_ix,illegal,clrw_ix,illegal,negw_ix,illegal,incw_ix,	/* c0 */
	illegal,decw_ix,illegal,tstw_ix,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* d0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* e0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* f0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal
};

static void (*const konami_direct[0x100])(void) = {
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 00 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,lda_di ,ldb_di ,illegal,illegal,adda_di,addb_di,	/* 10 */
	illegal,illegal,adca_di,adcb_di,illegal,illegal,suba_di,subb_di,
	illegal,illegal,sbca_di,sbcb_di,illegal,illegal,anda_di,andb_di,	/* 20 */
	illegal,illegal,bita_di,bitb_di,illegal,illegal,eora_di,eorb_di,
	illegal,illegal,ora_di ,orb_di ,illegal,illegal,cmpa_di,cmpb_di,	/* 30 */
	illegal,setline_di,sta_di,stb_di,illegal,illegal,illegal,illegal,
	illegal,ldd_di ,illegal,ldx_di ,illegal,ldy_di ,illegal,ldu_di ,	/* 40 */
	illegal,lds_di ,illegal,cmpd_di,illegal,cmpx_di,illegal,cmpy_di,
	illegal,cmpu_di,illegal,cmps_di,illegal,addd_di,illegal,subd_di,	/* 50 */
	std_di ,stx_di ,sty_di ,stu_di ,sts_di ,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 60 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 70 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,clr_di ,illegal,illegal,com_di ,illegal,illegal,	/* 80 */
	neg_di ,illegal,illegal,inc_di ,illegal,illegal,dec_di ,illegal,
	illegal,illegal,tst_di ,illegal,illegal,lsr_di ,illegal,illegal,	/* 90 */
	ror_di ,illegal,illegal,asr_di ,illegal,illegal,asl_di ,illegal,
	illegal,illegal,rol_di ,lsrw_di,rorw_di,asrw_di,aslw_di,rolw_di,	/* a0 */
	jmp_di ,jsr_di ,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* b0 */
	illegal,lsrd_di,illegal,rord_di,illegal,asrd_di,illegal,asld_di,
	illegal,rold_di,illegal,clrw_di,illegal,negw_di,illegal,incw_di,	/* c0 */
	illegal,decw_di,illegal,tstw_di,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* d0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* e0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* f0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal
};

static void (*const konami_extended[0x100])(void) = {
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 00 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,lda_ex ,ldb_ex ,illegal,illegal,adda_ex,addb_ex,	/* 10 */
	illegal,illegal,adca_ex,adcb_ex,illegal,illegal,suba_ex,subb_ex,
	illegal,illegal,sbca_ex,sbcb_ex,illegal,illegal,anda_ex,andb_ex,	/* 20 */
	illegal,illegal,bita_ex,bitb_ex,illegal,illegal,eora_ex,eorb_ex,
	illegal,illegal,ora_ex ,orb_ex ,illegal,illegal,cmpa_ex,cmpb_ex,	/* 30 */
	illegal,setline_ex,sta_ex,stb_ex,illegal,illegal,illegal,illegal,
	illegal,ldd_ex ,illegal,ldx_ex ,illegal,ldy_ex ,illegal,ldu_ex ,	/* 40 */
	illegal,lds_ex ,illegal,cmpd_ex,illegal,cmpx_ex,illegal,cmpy_ex,
	illegal,cmpu_ex,illegal,cmps_ex,illegal,addd_ex,illegal,subd_ex,	/* 50 */
	std_ex ,stx_ex ,sty_ex ,stu_ex ,sts_ex ,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 60 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* 70 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,clr_ex ,illegal,illegal,com_ex ,illegal,illegal,	/* 80 */
	neg_ex ,illegal,illegal,inc_ex ,illegal,illegal,dec_ex ,illegal,
	illegal,illegal,tst_ex ,illegal,illegal,lsr_ex ,illegal,illegal,	/* 90 */
	ror_ex ,illegal,illegal,asr_ex ,illegal,illegal,asl_ex ,illegal,
	illegal,illegal,rol_ex ,lsrw_ex,rorw_ex,asrw_ex,aslw_ex,rolw_ex,	/* a0 */
	jmp_ex ,jsr_ex ,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* b0 */
	illegal,lsrd_ex,illegal,rord_ex,illegal,asrd_ex,illegal,asld_ex,
	illegal,rold_ex,illegal,clrw_ex,illegal,negw_ex,illegal,incw_ex,	/* c0 */
	illegal,decw_ex,illegal,tstw_ex,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* d0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* e0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal,	/* f0 */
	illegal,illegal,illegal,illegal,illegal,illegal,illegal,illegal
};
