M6809_INLINE void abx(void);
M6809_INLINE void adca_di(void);
M6809_INLINE void adca_ex(void);
M6809_INLINE void adca_im(void);
M6809_INLINE void adca_ix(void);
M6809_INLINE void adcb_di(void);
M6809_INLINE void adcb_ex(void);
M6809_INLINE void adcb_im(void);
M6809_INLINE void adcb_ix(void);
M6809_INLINE void adda_di(void);
M6809_INLINE void adda_ex(void);
M6809_INLINE void adda_im(void);
M6809_INLINE void adda_ix(void);
M6809_INLINE void addb_di(void);
M6809_INLINE void addb_ex(void);
M6809_INLINE void addb_im(void);
M6809_INLINE void addb_ix(void);
M6809_INLINE void addd_di(void);
M6809_INLINE void addd_ex(void);
M6809_INLINE void addd_im(void);
M6809_INLINE void addd_ix(void);
M6809_INLINE void anda_di(void);
M6809_INLINE void anda_ex(void);
M6809_INLINE void anda_im(void);
M6809_INLINE void anda_ix(void);
M6809_INLINE void andb_di(void);
M6809_INLINE void andb_ex(void);
M6809_INLINE void andb_im(void);
M6809_INLINE void andb_ix(void);
M6809_INLINE void andcc(void);
M6809_INLINE void asl_di(void);
M6809_INLINE void asl_ex(void);
M6809_INLINE void asl_ix(void);
M6809_INLINE void asla(void);
M6809_INLINE void aslb(void);
M6809_INLINE void asr_di(void);
M6809_INLINE void asr_ex(void);
M6809_INLINE void asr_ix(void);
M6809_INLINE void asra(void);
M6809_INLINE void asrb(void);
M6809_INLINE void bcc(void);
M6809_INLINE void bcs(void);
M6809_INLINE void beq(void);
M6809_INLINE void bge(void);
M6809_INLINE void bgt(void);
M6809_INLINE void bhi(void);
M6809_INLINE void bita_di(void);
M6809_INLINE void bita_ex(void);
M6809_INLINE void bita_im(void);
M6809_INLINE void bita_ix(void);
M6809_INLINE void bitb_di(void);
M6809_INLINE void bitb_ex(void);
M6809_INLINE void bitb_im(void);
M6809_INLINE void bitb_ix(void);
M6809_INLINE void ble(void);
M6809_INLINE void bls(void);
M6809_INLINE void blt(void);
M6809_INLINE void bmi(void);
M6809_INLINE void bne(void);
M6809_INLINE void bpl(void);
M6809_INLINE void bra(void);
M6809_INLINE void brn(void);
M6809_INLINE void bsr(void);
M6809_INLINE void bvc(void);
M6809_INLINE void bvs(void);
M6809_INLINE void clr_di(void);
M6809_INLINE void clr_ex(void);
M6809_INLINE void clr_ix(void);
M6809_INLINE void clra(void);
M6809_INLINE void clrb(void);
M6809_INLINE void cmpa_di(void);
M6809_INLINE void cmpa_ex(void);
M6809_INLINE void cmpa_im(void);
M6809_INLINE void cmpa_ix(void);
M6809_INLINE void cmpb_di(void);
M6809_INLINE void cmpb_ex(void);
M6809_INLINE void cmpb_im(void);
M6809_INLINE void cmpb_ix(void);
M6809_INLINE void cmpd_di(void);
M6809_INLINE void cmpd_ex(void);
M6809_INLINE void cmpd_im(void);
M6809_INLINE void cmpd_ix(void);
M6809_INLINE void cmps_di(void);
M6809_INLINE void cmps_ex(void);
M6809_INLINE void cmps_im(void);
M6809_INLINE void cmps_ix(void);
M6809_INLINE void cmpu_di(void);
M6809_INLINE void cmpu_ex(void);
M6809_INLINE void cmpu_im(void);
M6809_INLINE void cmpu_ix(void);
M6809_INLINE void cmpx_di(void);
M6809_INLINE void cmpx_ex(void);
M6809_INLINE void cmpx_im(void);
M6809_INLINE void cmpx_ix(void);
M6809_INLINE void cmpy_di(void);
M6809_INLINE void cmpy_ex(void);
M6809_INLINE void cmpy_im(void);
M6809_INLINE void cmpy_ix(void);
M6809_INLINE void com_di(void);
M6809_INLINE void com_ex(void);
M6809_INLINE void com_ix(void);
M6809_INLINE void coma(void);
M6809_INLINE void comb(void);
M6809_INLINE void cwai(void);
M6809_INLINE void daa(void);
M6809_INLINE void dec_di(void);
M6809_INLINE void dec_ex(void);
M6809_INLINE void dec_ix(void);
M6809_INLINE void deca(void);
M6809_INLINE void decb(void);
M6809_INLINE void eora_di(void);
M6809_INLINE void eora_ex(void);
M6809_INLINE void eora_im(void);
M6809_INLINE void eora_ix(void);
M6809_INLINE void eorb_di(void);
M6809_INLINE void eorb_ex(void);
M6809_INLINE void eorb_im(void);
M6809_INLINE void eorb_ix(void);
M6809_INLINE void exg(void);
M6809_INLINE void illegal(void);
M6809_INLINE void inc_di(void);
M6809_INLINE void inc_ex(void);
M6809_INLINE void inc_ix(void);
M6809_INLINE void inca(void);
M6809_INLINE void incb(void);
M6809_INLINE void jmp_di(void);
M6809_INLINE void jmp_ex(void);
M6809_INLINE void jmp_ix(void);
M6809_INLINE void jsr_di(void);
M6809_INLINE void jsr_ex(void);
M6809_INLINE void jsr_ix(void);
M6809_INLINE void lbcc(void);
M6809_INLINE void lbcs(void);
M6809_INLINE void lbeq(void);
M6809_INLINE void lbge(void);
M6809_INLINE void lbgt(void);
M6809_INLINE void lbhi(void);
M6809_INLINE void lble(void);
M6809_INLINE void lbls(void);
M6809_INLINE void lblt(void);
M6809_INLINE void lbmi(void);
M6809_INLINE void lbne(void);
M6809_INLINE void lbpl(void);
M6809_INLINE void lbra(void);
M6809_INLINE void lbrn(void);
M6809_INLINE void lbsr(void);
M6809_INLINE void lbvc(void);
M6809_INLINE void lbvs(void);
M6809_INLINE void lda_di(void);
M6809_INLINE void lda_ex(void);
M6809_INLINE void lda_im(void);
M6809_INLINE void lda_ix(void);
M6809_INLINE void ldb_di(void);
M6809_INLINE void ldb_ex(void);
M6809_INLINE void ldb_im(void);
M6809_INLINE void ldb_ix(void);
M6809_INLINE void ldd_di(void);
M6809_INLINE void ldd_ex(void);
M6809_INLINE void ldd_im(void);
M6809_INLINE void ldd_ix(void);
M6809_INLINE void lds_di(void);
M6809_INLINE void lds_ex(void);
M6809_INLINE void lds_im(void);
M6809_INLINE void lds_ix(void);
M6809_INLINE void ldu_di(void);
M6809_INLINE void ldu_ex(void);
M6809_INLINE void ldu_im(void);
M6809_INLINE void ldu_ix(void);
M6809_INLINE void ldx_di(void);
M6809_INLINE void ldx_ex(void);
M6809_INLINE void ldx_im(void);
M6809_INLINE void ldx_ix(void);
M6809_INLINE void ldy_di(void);
M6809_INLINE void ldy_ex(void);
M6809_INLINE void ldy_im(void);
M6809_INLINE void ldy_ix(void);
M6809_INLINE void leas(void);
M6809_INLINE void leau(void);
M6809_INLINE void leax(void);
M6809_INLINE void leay(void);
M6809_INLINE void lsr_di(void);
M6809_INLINE void lsr_ex(void);
M6809_INLINE void lsr_ix(void);
M6809_INLINE void lsra(void);
M6809_INLINE void lsrb(void);
M6809_INLINE void mul(void);
M6809_INLINE void neg_di(void);
M6809_INLINE void neg_ex(void);
M6809_INLINE void neg_ix(void);
M6809_INLINE void nega(void);
M6809_INLINE void negb(void);
M6809_INLINE void nop(void);
M6809_INLINE void ora_di(void);
M6809_INLINE void ora_ex(void);
M6809_INLINE void ora_im(void);
M6809_INLINE void ora_ix(void);
M6809_INLINE void orb_di(void);
M6809_INLINE void orb_ex(void);
M6809_INLINE void orb_im(void);
M6809_INLINE void orb_ix(void);
M6809_INLINE void orcc(void);
M6809_INLINE void pshs(void);
M6809_INLINE void pshu(void);
M6809_INLINE void puls(void);
M6809_INLINE void pulu(void);
M6809_INLINE void rol_di(void);
M6809_INLINE void rol_ex(void);
M6809_INLINE void rol_ix(void);
M6809_INLINE void rola(void);
M6809_INLINE void rolb(void);
M6809_INLINE void ror_di(void);
M6809_INLINE void ror_ex(void);
M6809_INLINE void ror_ix(void);
M6809_INLINE void rora(void);
M6809_INLINE void rorb(void);
M6809_INLINE void rti(void);
M6809_INLINE void rts(void);
M6809_INLINE void sbca_di(void);
M6809_INLINE void sbca_ex(void);
M6809_INLINE void sbca_im(void);
M6809_INLINE void sbca_ix(void);
M6809_INLINE void sbcb_di(void);
M6809_INLINE void sbcb_ex(void);
M6809_INLINE void sbcb_im(void);
M6809_INLINE void sbcb_ix(void);
M6809_INLINE void sex(void);
M6809_INLINE void sta_di(void);
M6809_INLINE void sta_ex(void);
M6809_INLINE void sta_im(void);
M6809_INLINE void sta_ix(void);
M6809_INLINE void stb_di(void);
M6809_INLINE void stb_ex(void);
M6809_INLINE void stb_im(void);
M6809_INLINE void stb_ix(void);
M6809_INLINE void std_di(void);
M6809_INLINE void std_ex(void);
M6809_INLINE void std_im(void);
M6809_INLINE void std_ix(void);
M6809_INLINE void sts_di(void);
M6809_INLINE void sts_ex(void);
M6809_INLINE void sts_im(void);
M6809_INLINE void sts_ix(void);
M6809_INLINE void stu_di(void);
M6809_INLINE void stu_ex(void);
M6809_INLINE void stu_im(void);
M6809_INLINE void stu_ix(void);
M6809_INLINE void stx_di(void);
M6809_INLINE void stx_ex(void);
M6809_INLINE void stx_im(void);
M6809_INLINE void stx_ix(void);
M6809_INLINE void sty_di(void);
M6809_INLINE void sty_ex(void);
M6809_INLINE void sty_im(void);
M6809_INLINE void sty_ix(void);
M6809_INLINE void suba_di(void);
M6809_INLINE void suba_ex(void);
M6809_INLINE void suba_im(void);
M6809_INLINE void suba_ix(void);
M6809_INLINE void subb_di(void);
M6809_INLINE void subb_ex(void);
M6809_INLINE void subb_im(void);
M6809_INLINE void subb_ix(void);
M6809_INLINE void subd_di(void);
M6809_INLINE void subd_ex(void);
M6809_INLINE void subd_im(void);
M6809_INLINE void subd_ix(void);
M6809_INLINE void swi(void);
M6809_INLINE void swi2(void);
M6809_INLINE void swi3(void);
M6809_INLINE void sync(void);
M6809_INLINE void tfr(void);
M6809_INLINE void tst_di(void);
M6809_INLINE void tst_ex(void);
M6809_INLINE void tst_ix(void);
M6809_INLINE void tsta(void);
M6809_INLINE void tstb(void);

M6809_INLINE void pref10(void);
M6809_INLINE void pref11(void);

#if (BIG_SWITCH==0)
static void (*const m6809_main[0x100])(void) = {
	neg_di, neg_di, illegal,com_di, lsr_di, illegal,ror_di, asr_di, 	/* 00 */
	asl_di, rol_di, dec_di, illegal,inc_di, tst_di, jmp_di, clr_di,
	pref10, pref11, nop,	sync,	illegal,illegal,lbra,	lbsr,		/* 10 */
	illegal,daa,	orcc,	illegal,andcc,	sex,	exg,	tfr,
	bra,	brn,	bhi,	bls,	bcc,	bcs,	bne,	beq,		/* 20 */
	bvc,	bvs,	bpl,	bmi,	bge,	blt,	bgt,	ble,
	leax,	leay,	leas,	leau,	pshs,	puls,	pshu,	pulu,		/* 30 */
	illegal,rts,	abx,	rti,	cwai,	mul,	illegal,swi,
	nega,	illegal,illegal,coma,	lsra,	illegal,rora,	asra,		/* 40 */
	asla,	rola,	deca,	illegal,inca,	tsta,	illegal,clra,
	negb,	illegal,illegal,comb,	lsrb,	illegal,rorb,	asrb,		/* 50 */
	aslb,	rolb,	decb,	illegal,incb,	tstb,	illegal,clrb,
	neg_ix, illegal,illegal,com_ix, lsr_ix, illegal,ror_ix, asr_ix, 	/* 60 */
	asl_ix, rol_ix, dec_ix, illegal,inc_ix, tst_ix, jmp_ix, clr_ix,
	neg_ex, illegal,illegal,com_ex, lsr_ex, illegal,ror_ex, asr_ex, 	/* 70 */
	asl_ex, rol_ex, dec_ex, illegal,inc_ex, tst_ex, jmp_ex, clr_ex,
	suba_im,cmpa_im,sbca_im,subd_im,anda_im,bita_im,lda_im, sta_im, 	/* 80 */
	eora_im,adca_im,ora_im, adda_im,cmpx_im,bsr,	ldx_im, stx_im,
	suba_di,cmpa_di,sbca_di,subd_di,anda_di,bita_di,lda_di, sta_di, 	/* 90 */
	eora_di,adca_di,ora_di, adda_di,cmpx_di,jsr_di, ldx_di, stx_di,
	suba_ix,cmpa_ix,sbca_ix,subd_ix,anda_ix,bita_ix,lda_ix, sta_ix, 	/* a0 */
	eora_ix,adca_ix,ora_ix, adda_ix,cmpx_ix,jsr_ix, ldx_ix, stx_ix,
	suba_ex,cmpa_ex,sbca_ex,subd_ex,anda_ex,bita_ex,lda_ex, sta_ex, 	/* b0 */
	eora_ex,adca_ex,ora_ex, adda_ex,cmpx_ex,jsr_ex, ldx_ex, stx_ex,
	subb_im,cmpb_im,sbcb_im,addd_im,andb_im,bitb_im,ldb_im, stb_im, 	/* c0 */
	eorb_im,adcb_im,orb_im, addb_im,ldd_im, std_im, ldu_im, stu_im,
	subb_di,cmpb_di,sbcb_di,addd_di,andb_di,bitb_di,ldb_di, stb_di, 	/* d0 */
	eorb_di,adcb_di,orb_di, addb_di,ldd_di, std_di, ldu_di, stu_di,
	subb_ix,cmpb_ix,sbcb_ix,addd_ix,andb_ix,bitb_ix,ldb_ix, stb_ix, 	/* e0 */
	eorb_ix,adcb_ix,orb_ix, addb_ix,ldd_ix, std_ix, ldu_ix, stu_ix,
	subb_ex,cmpb_ex,sbcb_ex,addd_ex,andb_ex,bitb_ex,ldb_ex, stb_ex, 	/* f0 */
	eorb_ex,adcb_ex,orb_ex, addb_ex,ldd_ex, std_ex, ldu_ex, stu_ex
};
#endif
