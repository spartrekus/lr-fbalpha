// d3dkmt* functions aka SuperWaitVBlank

void SuperWaitVBlankInit();
void SuperWaitVBlankExit();
int SuperWaitVBlank();

extern bool bVidDWMSync;
