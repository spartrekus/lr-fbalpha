#include "burner.h"

TCHAR szAppPreviewsPath[MAX_PATH]	= _T("support\\previews\\");
TCHAR szAppTitlesPath[MAX_PATH]		= _T("support\\titles\\");
TCHAR szAppSelectPath[MAX_PATH]		= _T("support\\select\\");
TCHAR szAppVersusPath[MAX_PATH]		= _T("support\\versus\\");
TCHAR szAppHowtoPath[MAX_PATH]		= _T("support\\howto\\");
TCHAR szAppScoresPath[MAX_PATH]		= _T("support\\scores\\");
TCHAR szAppBossesPath[MAX_PATH]		= _T("support\\bosses\\");
TCHAR szAppGameoverPath[MAX_PATH]	= _T("support\\gameover\\");
TCHAR szAppFlyersPath[MAX_PATH]		= _T("support\\flyers\\");
TCHAR szAppMarqueesPath[MAX_PATH]	= _T("support\\marquees\\");
TCHAR szAppControlsPath[MAX_PATH]	= _T("support\\controls\\");
TCHAR szAppCabinetsPath[MAX_PATH]	= _T("support\\cabinets\\");
TCHAR szAppPCBsPath[MAX_PATH]		= _T("support\\pcbs\\");
TCHAR szAppCheatsPath[MAX_PATH]		= _T("support\\cheats\\");
TCHAR szAppHistoryPath[MAX_PATH]	= _T("support\\");
TCHAR szAppListsPath[MAX_PATH]		= _T("support\\lists\\lst\\");
TCHAR szAppDatListsPath[MAX_PATH]	= _T("support\\lists\\dat\\");
TCHAR szAppIpsPath[MAX_PATH]		= _T("support\\ips\\");
TCHAR szAppIconsPath[MAX_PATH]		= _T("support\\icons\\");
TCHAR szAppArchivesPath[MAX_PATH]	= _T("support\\archives\\");
TCHAR szAppHiscorePath[MAX_PATH]	= _T("support\\hiscores\\");
TCHAR szAppSamplesPath[MAX_PATH]	= _T("support\\samples\\");
TCHAR szAppBlendPath[MAX_PATH]		= _T("support\\blend\\");

TCHAR szCheckIconsPath[MAX_PATH];
