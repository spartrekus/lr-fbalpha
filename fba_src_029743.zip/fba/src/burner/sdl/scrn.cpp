
#include "burner.h"

void Reinitialise()
{
	//POST_INITIALISE_MESSAGE;
	VidReInitialise();
}
