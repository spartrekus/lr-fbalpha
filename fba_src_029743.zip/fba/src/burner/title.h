// Define macros for appliction title and description
#ifdef FBA_DEBUG
 #define APP_TITLE "FB Alpha [DEBUG]"
#else
 #define APP_TITLE "FB Alpha"
#endif

#define APP_DESCRIPTION "Emulator for arcade games"

