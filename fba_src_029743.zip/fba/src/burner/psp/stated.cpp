// State dialog module
#include "burner.h"

int bDrvSaveAll=0;

 
// The automatic save
int StatedAuto(int bSave)
{
	return 0;
}

static void CreateStateName(int nSlot)
{

}

int StatedLoad(int nSlot)		// int nSlot = 0
{
	return 0;
}

int StatedSave(int nSlot)		// int nSlot = 0
{
 
	return 0;
}
